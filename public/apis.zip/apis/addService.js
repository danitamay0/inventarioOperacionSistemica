
function addService(equipo, cliente) {

    formRegisterEquipoAndServicio.equipo_id.value = equipo;
    formRegisterEquipoAndServicio.cliente_id.value = cliente;

}
