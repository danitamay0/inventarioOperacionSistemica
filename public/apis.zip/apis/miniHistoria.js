window.onload = async () => {

    let html = '';
    const nodeRoot = document.getElementById('mhBody');

    const mini = await axios.get(`/minihistoria?equipo=${service.equipo.id}`);

    html = mini.data.map((service) => {
        return `<tr>
        <td> ${service.fecha_inicio} </td>
        <td> ${service.fecha_reparado} </td>
        <td> ${service.fecha_finalizado} </td>
        <td> ${service.cliente.fullname} </td>
        <td> ${service.cliente.identificacion} </td>
        <td> ${service.reporte} </td>
        <td> ${service.valor_cargo_cliente}</td>
        <td><ul>` + service.repuestos.map((repuesto) => { return `<li> Serie: ${repuesto.serie} Modelo: ${repuesto.modelo} </li>` }) + `</ul></td>
        </tr>`;
    });


    nodeRoot.insertAdjacentHTML("beforeend", html)

}